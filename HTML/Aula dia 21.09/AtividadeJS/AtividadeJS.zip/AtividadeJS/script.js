alert("APROVADOS E LOCAIS DE PROVA!")
console.log("APROVADOS E LOCAIS DE PROVA")
console.log(" ")
console.log(" ")

console.log("Lista de aprovados:")
let approved = ["Ana Cassia", "Ana Lucia", "Marcelo Alves", "Ana Júlia"]
approved.forEach(approved => {
    console.log(approved)
})

console.log(" ")

console.log("Locais das provas por ordem:")
let cities = ["Piracicaba", "Santos", "Americana", "Limeira"]
cities.forEach(cities => {
    console.log(cities)
})